﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int lowIndex;
            int highIndex;
            lowIndex = 1;
            highIndex = 5;
            int[] intArray = { 1, 2, 3, 4, 5, 6, 11, 14, 15, 19 };
            DisplayArray(intArray, lowIndex, highIndex); // pass an int array argument
            
        }

        private static T DisplayArray<T>(T[] inputArray, int y, int z) where T : IComparable<T>
        {

            //int[] Htemp  =  new int[z];
            T[] tmp = new T[20];
            //
            Console.WriteLine("---------------");
            //equal validation
            if (y.CompareTo(z) == 0 && y.CompareTo(z) == 1 && y > -1 && z <= inputArray.Length)
            {
                //throw exception 
                throw new ArgumentException("Same indexes does not work");
            }
            else {
                Console.WriteLine("---------------");
                //out of range validtion 
                
                
                    Console.WriteLine("---------------");
                    //execute code
                    var length = (z - y)+1;
                    for (var i = 0; i < length ; i++) {
                        tmp[i] = inputArray[y];
                        Console.Write(tmp[i]);
                            y++;
                    }

                    //Array.Copy(inputArray, y, Htemp, 0, z);
                    Console.WriteLine(tmp);
                    Console.WriteLine("---------------");
                    return (T)(Convert.ChangeType(tmp, typeof(T)));
                    
                    
                
                
            }

            Console.WriteLine("---------------");


            Console.WriteLine();
        }
        
    }
}
